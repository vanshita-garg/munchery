import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Admin_login extends JFrame {

	private JPanel contentPane;
	private JTextField n;
	private JPasswordField p;
 static Admin_login frame;
 /**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_login frame = new Admin_login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin_login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 566, 331);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(245, 245, 245));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("WELCOM ADMIN");
		lblNewLabel.setFont(new Font("Sitka Heading", Font.BOLD | Font.ITALIC, 36));
		lblNewLabel.setBounds(108, 10, 313, 55);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("USER NAME :");
		lblNewLabel_1.setFont(new Font("Yu Gothic", Font.BOLD, 25));
		lblNewLabel_1.setBounds(38, 92, 197, 49);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("PASSWORD :");
		lblNewLabel_2.setFont(new Font("Yu Gothic", Font.BOLD, 25));
		lblNewLabel_2.setBounds(38, 179, 197, 41);
		contentPane.add(lblNewLabel_2);
		
		n = new JTextField();
		n.setBounds(247, 92, 227, 38);
		contentPane.add(n);
		n.setColumns(10);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = n.getText();
				String password = p.getText();
				if(name.contains("vanshita")&&password.contains("1652"))
				{
					n.setText(null);
					p.setText(null);
				
				    dispose();
					admin_view dv = new admin_view();
					dv.setVisible(true);
				}
				
				else if(name.contains("aksha")&&password.contains("2004"))
				{
					n.setText(null);
					p.setText(null);
				
					 dispose();
				admin_view dv = new admin_view();
				dv.setVisible(true);
			}
				else
				{
					JOptionPane.showMessageDialog(null,"invalid login details","login error",JOptionPane.ERROR_MESSAGE);
					n.setText(null);
					p.setText(null);
				}
			}
		});
		btnNewButton.setFont(new Font("Sitka Display", Font.ITALIC, 30));
		btnNewButton.setBounds(379, 256, 133, 38);
		contentPane.add(btnNewButton);
		
		p = new JPasswordField();
		p.setBounds(247, 179, 227, 38);
		contentPane.add(p);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setFont(new Font("Sitka Display", Font.ITALIC, 30));
		btnNewButton_1.setBounds(10, 248, 148, 38);
		contentPane.add(btnNewButton_1);
	}
}
