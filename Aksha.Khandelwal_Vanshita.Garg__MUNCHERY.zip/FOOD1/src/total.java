import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTable;

public class total extends JFrame {

	private JPanel contentPane;
	private JTextField txttotal;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					total frame = new total();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public total() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 723, 432);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 104, 494, 264);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"TOTAL_AMT", "TAXES", "DELIVERY", "RCED_PYMT"
			}
		));
		scrollPane.setViewportView(table);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(64, 67, 494, 2);
		contentPane.add(separator);
		
		JButton btnNewButton = new JButton("SHOW");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Class.forName("com.ibm.db2.jcc.DB2Driver");
					Connection con=DriverManager.getConnection("jdbc:db2://localhost:50000/db1","db2admin","123456789");
				    Statement st = con.createStatement();
				    String v = "select * from tab7";
				    ResultSet rs = st.executeQuery(v);
				    
				    while(rs.next())
				    {
				    	String total_amt = rs.getString(1);
				    	String taxes = rs.getString(2);
				    	String delivery = rs.getString(3);
				    	String rced_pymt = rs.getString(4);
				    	 
			              String tbData[]= { total_amt,taxes,delivery,rced_pymt};
					    	DefaultTableModel tblModel=(DefaultTableModel)table.getModel();
					    	tblModel.addRow(tbData);
				    }
				   
				    }
				  
				    catch(Exception e2)
					{
						e2.printStackTrace();
					}
				

			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 19));
		btnNewButton.setBounds(5, 10, 137, 47);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("<< BACK");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			//	admin_view dv = new admin_view();
			//	dv.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		btnNewButton_1.setBounds(516, 10, 121, 47);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("TOTAL AMOUNT :-");
		lblNewLabel.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel.setBounds(509, 139, 190, 40);
		contentPane.add(lblNewLabel);
		
		txttotal = new JTextField();
		txttotal.setEnabled(false);
		txttotal.setBounds(516, 189, 183, 40);
		contentPane.add(txttotal);
		txttotal.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("TOTAL");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String c_amt;
				double prev_amt=0, curr_amt=0;
				try
				{
				Class.forName("com.ibm.db2.jcc.DB2Driver");
				Connection con = DriverManager.getConnection("jdbc:db2://localhost:50000/db1","db2admin", "123456789");
				//PreparedStatement ps =con.prepareStatement("insert into tab4 values(?)");
				Statement st = con.createStatement();
			    String v = "select * from tab7";
			    ResultSet rs = st.executeQuery(v);
			    while(rs.next())
			    {
			    	String r=rs.getString(4);
			    	 prev_amt = Integer.parseInt(r);
		                curr_amt += prev_amt;
			    }
			    
				}
				catch (Exception e2)
				{
					e2.printStackTrace();
				}
				c_amt = String.valueOf(curr_amt);
				txttotal.setText(c_amt);

			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.ITALIC, 16));
		btnNewButton_2.setBounds(552, 272, 104, 21);
		contentPane.add(btnNewButton_2);
	}
}
