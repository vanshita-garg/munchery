import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class admin_view extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admin_view frame = new admin_view();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public admin_view() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 697, 425);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(245, 245, 245));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CHECK FOR........");
		lblNewLabel.setFont(new Font("Palatino Linotype", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel.setBounds(10, 24, 290, 61);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("COSTUMER FEEDBACK");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 dispose();
				 feedback_view dv = new feedback_view();
					dv.setVisible(true);
			}
		});
		btnNewButton.setBounds(10, 138, 352, 63);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("MENU   ;)");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 dispose();
				 menu1 dv = new menu1();
					dv.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(372, 270, 306, 54);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("COSTUMER  DETAILS");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 dispose();
				 details dv = new details();
					dv.setVisible(true);
			}
		});
		btnNewButton_2.setBounds(12, 270, 350, 54);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("<< back");
		btnNewButton_3.setFont(new Font("Segoe Script", Font.BOLD, 20));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 dispose();
				 Admin_login dv = new Admin_login();
					dv.setVisible(true);
			}
		});
		btnNewButton_3.setBounds(481, 24, 138, 34);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("ORDER DETAILS");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 dispose();
				 total dv = new total();
					dv.setVisible(true);

				
				
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_4.setBounds(377, 139, 306, 61);
		contentPane.add(btnNewButton_4);
	}
}
