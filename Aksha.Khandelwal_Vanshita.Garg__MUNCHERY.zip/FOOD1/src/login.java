import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class login extends JFrame {
	

	private JPanel contentPane;
	static login frame ;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 616, 443);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(245, 245, 220));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome");
		lblNewLabel_1.setForeground(Color.BLUE);
		lblNewLabel_1.setFont(new Font("Cooper Black", Font.BOLD | Font.ITALIC, 65));
		lblNewLabel_1.setBounds(107, 39, 372, 94);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("User");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "To be continued");
				dispose();
				user obj = new user();
				obj.setVisible(true);
				
				
			}
		});
		btnNewButton.setFont(new Font("Bell MT", Font.BOLD | Font.ITALIC, 55));
		btnNewButton.setBounds(10, 275, 261, 100);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Admin");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Admin_login obj = new Admin_login();
				obj.setVisible(true);
				
				
			}
		});
		btnNewButton_1.setFont(new Font("Bell MT", Font.BOLD | Font.ITALIC, 55));
		btnNewButton_1.setBounds(327, 275, 261, 100);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("To Munchery");
		lblNewLabel_2.setForeground(Color.BLUE);
		lblNewLabel_2.setFont(new Font("Cooper Black", Font.BOLD | Font.ITALIC, 65));
		lblNewLabel_2.setBounds(55, 124, 472, 94);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel = new JLabel(" ");
		//Image img18 = new ImageIcon(this.getClass().getResource("/images/WhatsApp Image 2021-07-21 at 13.10.44 (1).jpeg")).getImage();
		lblNewLabel.setIcon(new ImageIcon(this.getClass().getResource("/image/WhatsApp Image 2021-07-21 at 13.10.44 (1).jpeg")));
		lblNewLabel.setBounds(0, 11, 602, 395);
		contentPane.add(lblNewLabel);
	}
}