import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class feedback extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	static feedback frame;
	private JTextField textField_1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new feedback();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public feedback() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 621, 347);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("YOUR ORDER IS CONFIRMED .... YOUR FOOD IS ON THE WAY  ");
		lblNewLabel.setFont(new Font("Yu Gothic UI Semilight", Font.BOLD | Font.ITALIC, 17));
		lblNewLabel.setBounds(50, 26, 571, 59);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("TAKE A MINUTE AND GIVE US A FEEDBCK :)");
		lblNewLabel_1.setFont(new Font("Sitka Display", Font.BOLD, 17));
		lblNewLabel_1.setBounds(10, 97, 349, 59);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(180, 222, 349, 29);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("FEEDBACK :=");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_2.setBounds(50, 225, 120, 19);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  String feed,name;
					feed=textField.getText();
					name=textField_1.getText();
					try
					{
					Class.forName("com.ibm.db2.jcc.DB2Driver");
					Connection con=DriverManager.getConnection("jdbc:db2://localhost:50000/db1","db2admin","123456789");
					PreparedStatement ps = con.prepareStatement("insert into tab2 values(?,?)");
					ps.setString(2,feed);
					ps.setString(1, name);
					
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"YOU HAVE SUCCESSFULLY SUBMITTED");
					dispose();
					thanks dv = new thanks();
					dv.setVisible(true);
						}
					
					catch(Exception e1)
					{
						e1.printStackTrace();
					}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		btnNewButton.setBounds(394, 261, 170, 39);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_3 = new JLabel("NAME :-");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_3.setBounds(57, 166, 80, 13);
		contentPane.add(lblNewLabel_3);
		
		textField_1 = new JTextField();
		textField_1.setBounds(180, 155, 189, 29);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
	}
}