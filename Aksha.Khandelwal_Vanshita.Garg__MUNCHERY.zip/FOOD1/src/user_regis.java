import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;

public class user_regis extends JFrame {

	private JPanel contentPane;
	private JTextField n;
	private JTextField ph;
	private JTextField em;
	private JPasswordField p;
	static user_regis frame;
	private JTextField ad;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new user_regis();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public user_regis() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 788, 584);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setFont(new Font("Algerian", Font.BOLD | Font.ITALIC, 35));
		lblNewLabel.setBounds(43, 10, 282, 80);
		contentPane.add(lblNewLabel);
		
		n = new JTextField();
		n.setBounds(299, 23, 422, 44);
		contentPane.add(n);
		n.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Phone Number");
		lblNewLabel_1.setFont(new Font("Algerian", Font.BOLD | Font.ITALIC, 35));
		lblNewLabel_1.setBounds(31, 88, 282, 80);
		contentPane.add(lblNewLabel_1);
		
		ph = new JTextField();
		ph.setBounds(323, 117, 386, 44);
		contentPane.add(ph);
		ph.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Email ID");
		lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 35));
		lblNewLabel_2.setBounds(31, 183, 282, 86);
		contentPane.add(lblNewLabel_2);
		
		em = new JTextField();
		em.setBounds(299, 202, 422, 44);
		contentPane.add(em);
		em.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Password");
		lblNewLabel_3.setFont(new Font("Algerian", Font.BOLD | Font.ITALIC, 35));
		lblNewLabel_3.setBounds(43, 356, 282, 80);
		contentPane.add(lblNewLabel_3);
		
		p = new JPasswordField();
		p.setBounds(299, 371, 422, 50);
		contentPane.add(p);
		
		JButton btnNewButton = new JButton("Register !!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String name,pass;
				String phone,email,add;
				name= n.getText();
				pass=p.getText();
				phone=ph.getText();
				email=em.getText();
				add=ad.getText();
				if(n.getText().trim().isEmpty() &&  p.getText().trim().isEmpty() && ph.getText().trim().isEmpty() && em.getText().trim().isEmpty() && ad.getText().trim().isEmpty())
				{
					JOptionPane.showMessageDialog(null, "FILL ALL DETAILS");
				}
				else if(n.getText().trim().isEmpty() )
				{
					JOptionPane.showMessageDialog(null, "ENTER NAME");
				}
				else if(  p.getText().trim().isEmpty() )
				{
					JOptionPane.showMessageDialog(null, "ENTER PASSWORD");
				}
				else if( ph.getText().trim().isEmpty() )
				{
					JOptionPane.showMessageDialog(null, "ENTER PHONE NUMBER");
				}
				else if( em.getText().trim().isEmpty())
				{
					JOptionPane.showMessageDialog(null, "ENTER E-MAIL");
				}
				else if( ad.getText().trim().isEmpty())
				{
					JOptionPane.showMessageDialog(null, "ENTER ADDRESS");
				}
				else
				{
				try
				{
				//registring the driver
				
			   Class.forName("com.ibm.db2.jcc.DB2Driver");
				Connection con = DriverManager.getConnection("jdbc:db2://localhost:50000/db1","db2admin", "123456789");
				PreparedStatement ps =con.prepareStatement("insert into tab4 values(?,?,?,?,?)");
				ps.setString(1,name);
				ps.setString(4,pass);
				ps.setString(3, email);
				ps.setString(2, phone);
				ps.setString(5, add);
				
				ps.executeUpdate();
				JOptionPane.showInternalMessageDialog(null, "sucessful");
				dispose();
				menu1 obj = new menu1();
				obj.setVisible(true);
				}
				catch(Exception e1)
				{
					e1.getStackTrace();
				}
				
				}
				
			}
		});
		btnNewButton.setFont(new Font("Arial Black", Font.BOLD | Font.ITALIC, 30));
		btnNewButton.setBounds(355, 466, 246, 71);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_4 = new JLabel("Address");
		lblNewLabel_4.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 35));
		lblNewLabel_4.setBounds(31, 290, 196, 45);
		contentPane.add(lblNewLabel_4);
		
		ad = new JTextField();
		ad.setBounds(299, 290, 422, 44);
		contentPane.add(ad);
	}
}