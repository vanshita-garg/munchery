import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JSplitPane;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JTextPane;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class menu1 extends JFrame {
	int iamt,itax=0,tax=20, ipay=0, div=50;
	int[] isum = new int[29];
	private JPanel contentPane;
	static menu1 frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JTextField textField_22;
	private JTextField textField_23;
	private JTextField textField_24;
	private JTextField textField_25;
	private JTextField textField_26;
	private JTextField textField_27;
	private JTextField textField_28;
	private JTextField textField_29;
	private JTextField textField_30;
	private JTextField textField_31;
	private JTextField textField_32;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				   frame = new menu1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public menu1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1161, 612);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("PIZZA");
		lblNewLabel.setBounds(10, 10, 226, 37);
		lblNewLabel.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 20));
		contentPane.add(lblNewLabel);
		
		JLabel Label_1 = new JLabel("Margherita Pizza");
		Label_1.setFont(new Font("Sitka Text", Font.BOLD, 14));
		Label_1.setBounds(33, 57, 129, 26);
		contentPane.add(Label_1);
		
		JLabel Label_2 = new JLabel("Peppy Paneer ");
		Label_2.setFont(new Font("Sitka Text", Font.BOLD, 14));
		Label_2.setBounds(33, 93, 129, 31);
		contentPane.add(Label_2);
		
		JLabel Label_3 = new JLabel("Farmhouse");
		Label_3.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		Label_3.setBounds(33, 134, 129, 31);
		contentPane.add(Label_3);
		
		JLabel Label_7 = new JLabel("Aloo Tikki");
		Label_7.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		Label_7.setBounds(33, 336, 129, 26);
		contentPane.add(Label_7);
		
		JLabel Label_8 = new JLabel("Schezwan Veg ");
		Label_8.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		Label_8.setBounds(33, 372, 129, 20);
		contentPane.add(Label_8);
		
		JLabel lblNewLabel_12 = new JLabel("");
		lblNewLabel_12.setBounds(33, 534, 45, 13);
		contentPane.add(lblNewLabel_12);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 4, true));
		panel.setBounds(10, 0, 398, 565);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel Label_5 = new JLabel("Moroccan Spice Pasta Pizza");
		Label_5.setBounds(24, 216, 186, 18);
		panel.add(Label_5);
		Label_5.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		
		JLabel Label_4 = new JLabel("Cheese n corn");
		Label_4.setBounds(24, 175, 93, 18);
		panel.add(Label_4);
		Label_4.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		
		JLabel Label_6 = new JLabel("Mexican Green Wave");
		Label_6.setBounds(24, 244, 141, 31);
		panel.add(Label_6);
		Label_6.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("");
		chckbxNewCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chckbxNewCheckBox.isSelected())
				{
					textField.setEnabled(true);
				}
				else
				{
					textField.setEnabled(false);
				}
			}
		});
		chckbxNewCheckBox.setBounds(193, 61, 21, 21);
		panel.add(chckbxNewCheckBox);
		
		JLabel lblNewLabel_7 = new JLabel("BURGERS");
		lblNewLabel_7.setBounds(10, 285, 226, 37);
		panel.add(lblNewLabel_7);
		lblNewLabel_7.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 20));
		
		JCheckBox CheckBox_1 = new JCheckBox("");
		CheckBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_1.isSelected())
				{
					textField_1.setEnabled(true);
				}
				else
				{
					textField_1.setEnabled(false);
				}
			}
		});
		CheckBox_1.setBounds(193, 97, 21, 21);
		panel.add(CheckBox_1);
		
		JCheckBox CheckBox_2 = new JCheckBox("");
		CheckBox_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_2.isSelected())
				{
					textField_2.setEnabled(true);
				}
				else
				{
					textField_2.setEnabled(false);
				}
				
			}
		});
		CheckBox_2.setBounds(193, 138, 21, 21);
		panel.add(CheckBox_2);
		
		JCheckBox CheckBox_3 = new JCheckBox("");
		CheckBox_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_3.isSelected())
				{
					textField_3.setEnabled(true);
				}
				else
				{
					textField_3.setEnabled(false);
				}
			}
		});
		CheckBox_3.setBounds(193, 175, 21, 21);
		panel.add(CheckBox_3);
		
		JCheckBox CheckBox_4 = new JCheckBox("");
		CheckBox_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_4.isSelected())
				{
					textField_4.setEnabled(true);
				}
				else
				{
					textField_4.setEnabled(false);
				}
			}
		});
		CheckBox_4.setBounds(223, 213, 21, 21);
		panel.add(CheckBox_4);
		
		JCheckBox CheckBox_5 = new JCheckBox("");
		CheckBox_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_5.isSelected())
				{
					textField_5.setEnabled(true);
				}
				else
				{
					textField_5.setEnabled(false);
				}
			}
		});
		CheckBox_5.setBounds(193, 247, 21, 21);
		panel.add(CheckBox_5);
		
		JLabel lblNewLabel_16 = new JLabel("100 Rs");
		lblNewLabel_16.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_16.setBounds(220, 65, 66, 17);
		panel.add(lblNewLabel_16);
		
		JLabel lblNewLabel_13 = new JLabel("120 Rs");
		lblNewLabel_13.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_13.setBounds(220, 99, 66, 18);
		panel.add(lblNewLabel_13);
		
		JLabel lblNewLabel_18 = new JLabel("250 Rs");
		lblNewLabel_18.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_18.setBounds(220, 138, 66, 17);
		panel.add(lblNewLabel_18);
		
		JLabel lblNewLabel_19 = new JLabel("120 Rs");
		lblNewLabel_19.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_19.setBounds(223, 175, 63, 18);
		panel.add(lblNewLabel_19);
		
		JLabel lblNewLabel_20 = new JLabel("300 Rs");
		lblNewLabel_20.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_20.setBounds(246, 216, 60, 16);
		panel.add(lblNewLabel_20);
		
		JLabel lblNewLabel_21 = new JLabel("280 Rs");
		lblNewLabel_21.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_21.setBounds(223, 244, 63, 22);
		panel.add(lblNewLabel_21);
		
		JCheckBox CheckBox_6 = new JCheckBox("");
		CheckBox_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_6.isSelected())
				{
					textField_6.setEnabled(true);
				}
				else
				{
					textField_6.setEnabled(false);
				}
			}
		});
		CheckBox_6.setBounds(193, 333, 21, 21);
		panel.add(CheckBox_6);
		
		JCheckBox CheckBox_7 = new JCheckBox("");
		CheckBox_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_7.isSelected())
				{
					textField_7.setEnabled(true);
				}
				else
				{
					textField_7.setEnabled(false);
				}
			}
		});
		CheckBox_7.setBounds(193, 370, 21, 21);
		panel.add(CheckBox_7);
		
		JCheckBox CheckBox_8 = new JCheckBox("");
		CheckBox_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_8.isSelected())
				{
					textField_8.setEnabled(true);
				}
				else
				{
					textField_8.setEnabled(false);
				}
			}
		});
		CheckBox_8.setBounds(193, 412, 21, 21);
		panel.add(CheckBox_8);
		
		JLabel Label_9 = new JLabel("Maharaja burger");
		Label_9.setBounds(24, 414, 129, 20);
		panel.add(Label_9);
		Label_9.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		
		JLabel Label_10 = new JLabel("muncherry special");
		Label_10.setBounds(24, 447, 129, 26);
		panel.add(Label_10);
		Label_10.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		
		JCheckBox CheckBox_9 = new JCheckBox("");
		CheckBox_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_9.isSelected())
				{
					textField_9.setEnabled(true);
				}
				else
				{
					textField_9.setEnabled(false);
				}
			}
		});
		CheckBox_9.setBounds(193, 448, 21, 21);
		panel.add(CheckBox_9);
		
		JLabel lblNewLabel_22 = new JLabel("Double Aloo Tikki");
		lblNewLabel_22.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_22.setBounds(24, 483, 129, 25);
		panel.add(lblNewLabel_22);
		
		JLabel lblNewLabel_23 = new JLabel("Cheese Burger");
		lblNewLabel_23.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_23.setBounds(24, 525, 129, 18);
		panel.add(lblNewLabel_23);
		
		JCheckBox CheckBox_10 = new JCheckBox("");
		CheckBox_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_10.isSelected())
				{
					textField_10.setEnabled(true);
				}
				else
				{
					textField_10.setEnabled(false);
				}
			}
		});
		CheckBox_10.setBounds(193, 483, 21, 21);
		panel.add(CheckBox_10);
		
		JCheckBox CheckBox_11 = new JCheckBox("");
		CheckBox_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_11.isSelected())
				{
					textField_11.setEnabled(true);
				}
				else
				{
					textField_11.setEnabled(false);
				}
			}
		});
		CheckBox_11.setBounds(193, 522, 21, 21);
		panel.add(CheckBox_11);
		
		JLabel lblNewLabel_24 = new JLabel("80 Rs");
		lblNewLabel_24.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_24.setBounds(228, 332, 45, 22);
		panel.add(lblNewLabel_24);
		
		JLabel lblNewLabel_25 = new JLabel("100 Rs");
		lblNewLabel_25.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_25.setBounds(223, 373, 50, 18);
		panel.add(lblNewLabel_25);
		
		JLabel lblNewLabel_26 = new JLabel("150 Rs");
		lblNewLabel_26.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_26.setBounds(223, 412, 63, 21);
		panel.add(lblNewLabel_26);
		
		JLabel lblNewLabel_27 = new JLabel("110 Rs");
		lblNewLabel_27.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_27.setBounds(223, 447, 50, 18);
		panel.add(lblNewLabel_27);
		
		JLabel lblNewLabel_28 = new JLabel("100 Rs");
		lblNewLabel_28.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_28.setBounds(223, 483, 50, 17);
		panel.add(lblNewLabel_28);
		
		JLabel lblNewLabel_29 = new JLabel("90 Rs");
		lblNewLabel_29.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_29.setBounds(223, 521, 50, 18);
		panel.add(lblNewLabel_29);
		
		textField = new JTextField();
		textField.setEnabled(false);
		textField.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField.setText("0");
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
			}
		});
		textField.setBounds(296, 61, 94, 19);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setEnabled(false);
		textField_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_1.setText("0");
		textField_1.setBounds(294, 97, 96, 19);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setEnabled(false);
		textField_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_2.setText("0");
		textField_2.setBounds(294, 138, 96, 19);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setEnabled(false);
		textField_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_3.setText("0");
		textField_3.setBounds(296, 173, 96, 19);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setEnabled(false);
		textField_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_4.setText("0");
		textField_4.setBounds(294, 214, 96, 19);
		panel.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setEnabled(false);
		textField_5.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_5.setText("0");
		textField_5.setBounds(294, 248, 96, 19);
		panel.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setEnabled(false);
		textField_6.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_6.setText("0");
		textField_6.setBounds(294, 335, 96, 19);
		panel.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setEnabled(false);
		textField_7.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_7.setText("0");
		textField_7.setBounds(294, 372, 96, 19);
		panel.add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setEnabled(false);
		textField_8.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_8.setText("0");
		textField_8.setBounds(294, 412, 96, 19);
		panel.add(textField_8);
		textField_8.setColumns(10);
		
		textField_9 = new JTextField();
		textField_9.setEnabled(false);
		textField_9.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_9.setText("0");
		textField_9.setBounds(294, 452, 96, 19);
		panel.add(textField_9);
		textField_9.setColumns(10);
		
		textField_10 = new JTextField();
		textField_10.setEnabled(false);
		textField_10.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_10.setText("0");
		textField_10.setBounds(294, 484, 96, 19);
		panel.add(textField_10);
		textField_10.setColumns(10);
		
		textField_11 = new JTextField();
		textField_11.setEnabled(false);
		textField_11.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_11.setText("0");
		textField_11.setBounds(294, 523, 96, 19);
		panel.add(textField_11);
		textField_11.setColumns(10);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 4));
		panel_2.setBounds(799, 10, 338, 493);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_14 = new JLabel("Shakes");
		lblNewLabel_14.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_14.setBounds(10, 10, 144, 31);
		panel_2.add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel("Chocolate");
		lblNewLabel_15.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_15.setBounds(25, 51, 89, 24);
		panel_2.add(lblNewLabel_15);
		
		JLabel lblNewLabel_30 = new JLabel("Cherry-Vanilla");
		lblNewLabel_30.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_30.setBounds(25, 89, 99, 24);
		panel_2.add(lblNewLabel_30);
		
		JLabel lblNewLabel_31 = new JLabel("Strawberry");
		lblNewLabel_31.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_31.setBounds(25, 126, 89, 24);
		panel_2.add(lblNewLabel_31);
		
		JLabel lblNewLabel_32 = new JLabel("Vanilla special");
		lblNewLabel_32.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_32.setBounds(12, 149, 112, 31);
		panel_2.add(lblNewLabel_32);
		
		JLabel lblNewLabel_33 = new JLabel("Candy Fantasy");
		lblNewLabel_33.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_33.setBounds(10, 185, 114, 24);
		panel_2.add(lblNewLabel_33);
		
		JLabel lblNewLabel_34 = new JLabel("Cookies & Cream");
		lblNewLabel_34.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_34.setBounds(20, 221, 117, 24);
		panel_2.add(lblNewLabel_34);
		
		JCheckBox CheckBox_18 = new JCheckBox("");
		CheckBox_18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_18.isSelected())
				{
					textField_18.setEnabled(true);
				}
				else
				{
					textField_18.setEnabled(false);
				}
			}
		});
		CheckBox_18.setBounds(121, 51, 21, 21);
		panel_2.add(CheckBox_18);
		
		JLabel lblNewLabel_35 = new JLabel("70 Rs");
		lblNewLabel_35.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_35.setBounds(154, 51, 66, 17);
		panel_2.add(lblNewLabel_35);
		
		JCheckBox CheckBox_19 = new JCheckBox("");
		CheckBox_19.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_19.isSelected())
				{
					textField_19.setEnabled(true);
				}
				else
				{
					textField_19.setEnabled(false);
				}
			}
		});
		CheckBox_19.setBounds(127, 89, 21, 21);
		panel_2.add(CheckBox_19);
		
		JCheckBox CheckBox_20 = new JCheckBox("New check box");
		CheckBox_20.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_20.isSelected())
				{
					textField_20.setEnabled(true);
				}
				else
				{
					textField_20.setEnabled(false);
				}
			}
		});
		CheckBox_20.setBounds(127, 126, 21, 21);
		panel_2.add(CheckBox_20);
		
		JCheckBox CheckBox_21 = new JCheckBox("New check box");
		CheckBox_21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_21.isSelected())
				{
					textField_21.setEnabled(true);
				}
				else
				{
					textField_21.setEnabled(false);
				}
			}
		});
		CheckBox_21.setBounds(127, 152, 21, 21);
		panel_2.add(CheckBox_21);
		
		JCheckBox CheckBox_22 = new JCheckBox("New check box");
		CheckBox_22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_22.isSelected())
				{
					textField_22.setEnabled(true);
				}
				else
				{
					textField_22.setEnabled(false);
				}
			}
		});
		CheckBox_22.setBounds(127, 185, 21, 21);
		panel_2.add(CheckBox_22);
		
		JCheckBox CheckBox_23 = new JCheckBox("New check box");
		CheckBox_23.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_23.isSelected())
				{
					textField_23.setEnabled(true);
				}
				else
				{
					textField_23.setEnabled(false);
				}
			}
		});
		CheckBox_23.setBounds(143, 221, 21, 21);
		panel_2.add(CheckBox_23);
		
		JLabel lblNewLabel_36 = new JLabel("DRINKS");
		lblNewLabel_36.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_36.setBounds(10, 272, 144, 31);
		panel_2.add(lblNewLabel_36);
		
		JLabel coke = new JLabel("Coke");
		coke.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		coke.setBounds(25, 315, 45, 24);
		panel_2.add(coke);
		
		JLabel lblNewLabel_38 = new JLabel("Fanta");
		lblNewLabel_38.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_38.setBounds(25, 349, 45, 30);
		panel_2.add(lblNewLabel_38);
		
		JLabel lblNewLabel_39 = new JLabel("Sprite");
		lblNewLabel_39.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_39.setBounds(25, 399, 45, 20);
		panel_2.add(lblNewLabel_39);
		
		JLabel lblNewLabel_40 = new JLabel("Cold Coffee");
		lblNewLabel_40.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_40.setBounds(25, 429, 77, 25);
		panel_2.add(lblNewLabel_40);
		
		JLabel lblNewLabel_41 = new JLabel("Fresh Lemon Soda");
		lblNewLabel_41.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_41.setBounds(10, 464, 136, 24);
		panel_2.add(lblNewLabel_41);
		
		JCheckBox CheckBox_24 = new JCheckBox("New check box");
		CheckBox_24.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_24.isSelected())
				{
					textField_24.setEnabled(true);
				}
				else
				{
					textField_24.setEnabled(false);
				}
			}
		});
		CheckBox_24.setBounds(143, 315, 21, 21);
		panel_2.add(CheckBox_24);
		
		JCheckBox CheckBox_25 = new JCheckBox("New check box");
		CheckBox_25.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_25.isSelected())
				{
					textField_25.setEnabled(true);
				}
				else
				{
					textField_25.setEnabled(false);
				}
			}
		});
		CheckBox_25.setBounds(143, 352, 21, 21);
		panel_2.add(CheckBox_25);
		
		JCheckBox CheckBox_26 = new JCheckBox("New check box");
		CheckBox_26.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_26.isSelected())
				{
					textField_26.setEnabled(true);
				}
				else
				{
					textField_26.setEnabled(false);
				}
			}
		});
		CheckBox_26.setBounds(143, 397, 21, 21);
		panel_2.add(CheckBox_26);
		
		JCheckBox CheckBox_27 = new JCheckBox("New check box");
		CheckBox_27.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_27.isSelected())
				{
					textField_27.setEnabled(true);
				}
				else
				{
					textField_27.setEnabled(false);
				}
			}
		});
		CheckBox_27.setBounds(143, 429, 21, 21);
		panel_2.add(CheckBox_27);
		
		JCheckBox CheckBox_28 = new JCheckBox("New check box");
		CheckBox_28.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_28.isSelected())
				{
					textField_28.setEnabled(true);
				}
				else
				{
					textField_28.setEnabled(false);
				}
			}
		});
		CheckBox_28.setBounds(143, 464, 21, 21);
		panel_2.add(CheckBox_28);
		
		JLabel lblNewLabel_56 = new JLabel("80 Rs");
		lblNewLabel_56.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_56.setBounds(154, 89, 66, 17);
		panel_2.add(lblNewLabel_56);
		
		JLabel lblNewLabel_57 = new JLabel("70 Rs");
		lblNewLabel_57.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_57.setBounds(154, 126, 66, 17);
		panel_2.add(lblNewLabel_57);
		
		JLabel lblNewLabel_58 = new JLabel("80 Rs");
		lblNewLabel_58.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_58.setBounds(154, 154, 66, 20);
		panel_2.add(lblNewLabel_58);
		
		JLabel lblNewLabel_59 = new JLabel("90 Rs");
		lblNewLabel_59.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_59.setBounds(154, 189, 66, 13);
		panel_2.add(lblNewLabel_59);
		
		JLabel lblNewLabel_60 = new JLabel("100 Rs");
		lblNewLabel_60.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_60.setBounds(170, 221, 50, 17);
		panel_2.add(lblNewLabel_60);
		
		JLabel lblNewLabel_61 = new JLabel("50 Rs");
		lblNewLabel_61.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_61.setBounds(175, 315, 45, 17);
		panel_2.add(lblNewLabel_61);
		
		JLabel lblNewLabel_62 = new JLabel("50 Rs");
		lblNewLabel_62.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_62.setBounds(175, 349, 45, 20);
		panel_2.add(lblNewLabel_62);
		
		JLabel lblNewLabel_63 = new JLabel("50 Rs");
		lblNewLabel_63.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_63.setBounds(175, 399, 45, 15);
		panel_2.add(lblNewLabel_63);
		
		JLabel lblNewLabel_64 = new JLabel("70 Rs");
		lblNewLabel_64.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_64.setBounds(175, 429, 45, 25);
		panel_2.add(lblNewLabel_64);
		
		JLabel lblNewLabel_65 = new JLabel("60 Rs");
		lblNewLabel_65.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_65.setBounds(175, 464, 45, 17);
		panel_2.add(lblNewLabel_65);
		
		textField_18 = new JTextField();
		textField_18.setEnabled(false);
		textField_18.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_18.setText("0");
		textField_18.setBounds(232, 52, 96, 19);
		panel_2.add(textField_18);
		textField_18.setColumns(10);
		
		textField_19 = new JTextField();
		textField_19.setEnabled(false);
		textField_19.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_19.setText("0");
		textField_19.setBounds(232, 90, 96, 19);
		panel_2.add(textField_19);
		textField_19.setColumns(10);
		
		textField_20 = new JTextField();
		textField_20.setEnabled(false);
		textField_20.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_20.setText("0");
		textField_20.setBounds(232, 127, 96, 19);
		panel_2.add(textField_20);
		textField_20.setColumns(10);
		
		textField_21 = new JTextField();
		textField_21.setEnabled(false);
		textField_21.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_21.setText("0");
		textField_21.setBounds(232, 153, 96, 19);
		panel_2.add(textField_21);
		textField_21.setColumns(10);
		
		textField_22 = new JTextField();
		textField_22.setEnabled(false);
		textField_22.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_22.setText("0");
		textField_22.setBounds(232, 186, 96, 19);
		panel_2.add(textField_22);
		textField_22.setColumns(10);
		
		textField_23 = new JTextField();
		textField_23.setEnabled(false);
		textField_23.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_23.setText("0");
		textField_23.setBounds(232, 222, 96, 19);
		panel_2.add(textField_23);
		textField_23.setColumns(10);
		
		textField_24 = new JTextField();
		textField_24.setEnabled(false);
		textField_24.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_24.setText("0");
		textField_24.setBounds(230, 316, 96, 19);
		panel_2.add(textField_24);
		textField_24.setColumns(10);
		
		textField_25 = new JTextField();
		textField_25.setEnabled(false);
		textField_25.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_25.setText("0");
		textField_25.setBounds(232, 353, 96, 19);
		panel_2.add(textField_25);
		textField_25.setColumns(10);
		
		textField_26 = new JTextField();
		textField_26.setEnabled(false);
		textField_26.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_26.setText("0");
		textField_26.setBounds(232, 398, 96, 19);
		panel_2.add(textField_26);
		textField_26.setColumns(10);
		
		textField_27 = new JTextField();
		textField_27.setEnabled(false);
		textField_27.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_27.setText("0");
		textField_27.setBounds(232, 438, 96, 19);
		panel_2.add(textField_27);
		textField_27.setColumns(10);
		
		textField_28 = new JTextField();
		textField_28.setEnabled(false);
		textField_28.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_28.setText("0");
		textField_28.setBounds(232, 465, 96, 19);
		panel_2.add(textField_28);
		textField_28.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 4));
		panel_1.setBounds(418, 10, 371, 276);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_42 = new JLabel("NOODLES");
		lblNewLabel_42.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_42.setBounds(10, 10, 114, 21);
		panel_1.add(lblNewLabel_42);
		
		JLabel lblNewLabel_43 = new JLabel("Schezwan");
		lblNewLabel_43.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_43.setBounds(20, 33, 66, 21);
		panel_1.add(lblNewLabel_43);
		
		JLabel lblNewLabel_44 = new JLabel("Veggie Noodle");
		lblNewLabel_44.setFont(new Font("Sitka Subheading", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel_44.setBounds(20, 77, 104, 13);
		panel_1.add(lblNewLabel_44);
		
		JLabel lblNewLabel_45 = new JLabel("Hakka Noodle");
		lblNewLabel_45.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_45.setBounds(20, 114, 94, 13);
		panel_1.add(lblNewLabel_45);
		
		JLabel lblNewLabel_46 = new JLabel("ROLLS");
		lblNewLabel_46.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_46.setBounds(10, 137, 114, 21);
		panel_1.add(lblNewLabel_46);
		
		JLabel lblNewLabel_47 = new JLabel("Spring Roll");
		lblNewLabel_47.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_47.setBounds(20, 160, 82, 21);
		panel_1.add(lblNewLabel_47);
		
		JLabel lblNewLabel_48 = new JLabel("Kathi Roll");
		lblNewLabel_48.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_48.setBounds(20, 191, 94, 24);
		panel_1.add(lblNewLabel_48);
		
		JLabel lblNewLabel_49 = new JLabel("Special");
		lblNewLabel_49.setFont(new Font("Sitka Subheading", Font.BOLD, 14));
		lblNewLabel_49.setBounds(20, 235, 82, 31);
		panel_1.add(lblNewLabel_49);
		
		JCheckBox CheckBox_12 = new JCheckBox("");
		CheckBox_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_12.isSelected())
				{
					textField_12.setEnabled(true);
				}
				else
				{
					textField_12.setEnabled(false);
				}
			}
		});
		CheckBox_12.setBounds(130, 33, 21, 21);
		panel_1.add(CheckBox_12);
		
		JCheckBox CheckBox_13 = new JCheckBox("");
		CheckBox_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_13.isSelected())
				{
					textField_13.setEnabled(true);
				}
				else
				{
					textField_13.setEnabled(false);
				}
			}
		});
		CheckBox_13.setBounds(130, 71, 21, 21);
		panel_1.add(CheckBox_13);
		
		JCheckBox CheckBox_14 = new JCheckBox("");
		CheckBox_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_14.isSelected())
				{
					textField_14.setEnabled(true);
				}
				else
				{
					textField_14.setEnabled(false);
				}
			}
		});
		CheckBox_14.setBounds(130, 108, 21, 21);
		panel_1.add(CheckBox_14);
		
		JCheckBox CheckBox_15 = new JCheckBox("");
		CheckBox_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_15.isSelected())
				{
					textField_15.setEnabled(true);
				}
				else
				{
					textField_15.setEnabled(false);
				}
			}
		});
		CheckBox_15.setBounds(130, 160, 21, 21);
		panel_1.add(CheckBox_15);
		
		JCheckBox CheckBox_16 = new JCheckBox("");
		CheckBox_16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_16.isSelected())
				{
					textField_16.setEnabled(true);
				}
				else
				{
					textField_16.setEnabled(false);
				}
			}
		});
		CheckBox_16.setBounds(130, 191, 21, 21);
		panel_1.add(CheckBox_16);
		
		JCheckBox CheckBox_17 = new JCheckBox("");
		CheckBox_17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(CheckBox_17.isSelected())
				{
					textField_17.setEnabled(true);
				}
				else
				{
					textField_17.setEnabled(false);
				}
			}
		});
		CheckBox_17.setBounds(130, 235, 21, 21);
		panel_1.add(CheckBox_17);
		
		JLabel lblNewLabel_50 = new JLabel("80 Rs");
		lblNewLabel_50.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_50.setBounds(198, 35, 45, 19);
		panel_1.add(lblNewLabel_50);
		
		JLabel lblNewLabel_51 = new JLabel("90 Rs");
		lblNewLabel_51.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_51.setBounds(198, 71, 45, 17);
		panel_1.add(lblNewLabel_51);
		
		JLabel lblNewLabel_52 = new JLabel("70 Rs");
		lblNewLabel_52.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_52.setBounds(198, 112, 45, 15);
		panel_1.add(lblNewLabel_52);
		
		JLabel lblNewLabel_53 = new JLabel("80 Rs");
		lblNewLabel_53.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_53.setBounds(198, 154, 45, 21);
		panel_1.add(lblNewLabel_53);
		
		JLabel lblNewLabel_54 = new JLabel("85 Rs");
		lblNewLabel_54.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_54.setBounds(189, 187, 54, 21);
		panel_1.add(lblNewLabel_54);
		
		JLabel lblNewLabel_55 = new JLabel("90 Rs");
		lblNewLabel_55.setFont(new Font("Sitka Text", Font.BOLD, 14));
		lblNewLabel_55.setBounds(198, 235, 45, 20);
		panel_1.add(lblNewLabel_55);
		
		textField_12 = new JTextField();
		textField_12.setEnabled(false);
		textField_12.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_12.setText("0");
		textField_12.setBounds(265, 32, 96, 19);
		panel_1.add(textField_12);
		textField_12.setColumns(10);
		
		textField_13 = new JTextField();
		textField_13.setEnabled(false);
		textField_13.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_13.setText("0");
		textField_13.setBounds(265, 72, 96, 19);
		panel_1.add(textField_13);
		textField_13.setColumns(10);
		
		textField_14 = new JTextField();
		textField_14.setEnabled(false);
		textField_14.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_14.setText("0");
		textField_14.setBounds(265, 109, 96, 19);
		panel_1.add(textField_14);
		textField_14.setColumns(10);
		
		textField_15 = new JTextField();
		textField_15.setEnabled(false);
		textField_15.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_15.setText("0");
		textField_15.setBounds(265, 159, 96, 19);
		panel_1.add(textField_15);
		textField_15.setColumns(10);
		
		textField_16 = new JTextField();
		textField_16.setEnabled(false);
		textField_16.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_16.setText("0");
		textField_16.setBounds(265, 192, 96, 19);
		panel_1.add(textField_16);
		textField_16.setColumns(10);
		
		textField_17 = new JTextField();
		textField_17.setEnabled(false);
		textField_17.setFont(new Font("Tahoma", Font.BOLD, 13));
		textField_17.setText("0");
		textField_17.setBounds(265, 239, 96, 19);
		panel_1.add(textField_17);
		textField_17.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("RESET");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				textField.setText(null);
				textField_1.setText(null);
				textField_2.setText(null);
				textField_3.setText(null);
				textField_4.setText(null);
				textField_5.setText(null);
				textField_6.setText(null);
				textField_7.setText(null);
				textField_8.setText(null);
				textField_9.setText(null);
				textField_10.setText(null);
				textField_11.setText(null);
				textField_12.setText(null);
				textField_13.setText(null);
				textField_14.setText(null);
				textField_15.setText(null);
				textField_16.setText(null);
				textField_17.setText(null);
				textField_18.setText(null);
				textField_19.setText(null);
				textField_20.setText(null);
				textField_21.setText(null);
				textField_22.setText(null);
				textField_23.setText(null);
				textField_24.setText(null);
				textField_25.setText(null);
				textField_26.setText(null);
				textField_27.setText(null);
				textField_28.setText(null);
				
				chckbxNewCheckBox.setSelected(false);
				CheckBox_1.setSelected(false);
				CheckBox_2.setSelected(false);
				CheckBox_3.setSelected(false);
				CheckBox_3.setSelected(false);
				CheckBox_4.setSelected(false);
				CheckBox_5.setSelected(false);
				CheckBox_6.setSelected(false);
				CheckBox_7.setSelected(false);
				CheckBox_8.setSelected(false);
				CheckBox_9.setSelected(false);
				CheckBox_10.setSelected(false);
				CheckBox_11.setSelected(false);
				CheckBox_18.setSelected(false);
				CheckBox_19.setSelected(false);
				CheckBox_20.setSelected(false);
				CheckBox_21.setSelected(false);
				CheckBox_22.setSelected(false);
				CheckBox_23.setSelected(false);
				CheckBox_24.setSelected(false);
				CheckBox_25.setSelected(false);
				CheckBox_26.setSelected(false);
				CheckBox_27.setSelected(false);
				CheckBox_28.setSelected(false);
				CheckBox_12.setSelected(false);
				CheckBox_13.setSelected(false);
				CheckBox_14.setSelected(false);
				CheckBox_15.setSelected(false);
				CheckBox_16.setSelected(false);
				CheckBox_17.setSelected(false);
				
			}
		});
		btnNewButton_1.setBounds(898, 513, 108, 52);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("EXIT");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_2.addActionListener(new ActionListener() { 
			private JFrame frame;
			public void actionPerformed(ActionEvent e)
			{
				frame = new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frame,"confirm if you want to exit", "FAST FOOD", JOptionPane.YES_NO_OPTION )==JOptionPane.YES_NO_OPTION)
				{
					System.exit(0);
				}
			}
		});
		btnNewButton_2.setBounds(1016, 513, 121, 52);
		contentPane.add(btnNewButton_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.BLACK);
		panel_3.setBorder(new LineBorder(Color.WHITE, 4));
		panel_3.setBounds(418, 296, 366, 257);
		contentPane.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("TOTAL:-");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_1.setBounds(10, 10, 97, 27);
		panel_3.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("TAX:-");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBounds(10, 47, 97, 23);
		panel_3.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("DELIVERY:-");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setBounds(10, 80, 115, 23);
		panel_3.add(lblNewLabel_3);
		
		textField_29 = new JTextField();
		textField_29.setForeground(Color.BLUE);
		textField_29.setFont(new Font("Tahoma", Font.BOLD, 22));
		textField_29.setEnabled(false);
		textField_29.setBounds(184, 18, 96, 19);
		panel_3.add(textField_29);
		textField_29.setColumns(10);
		
		textField_30 = new JTextField();
		textField_30.setFont(new Font("Tahoma", Font.BOLD, 20));
		textField_30.setEnabled(false);
		textField_30.setBounds(184, 53, 96, 19);
		panel_3.add(textField_30);
		textField_30.setColumns(10);
		
		textField_31 = new JTextField();
		textField_31.setFont(new Font("Tahoma", Font.BOLD, 19));
		textField_31.setEnabled(false);
		textField_31.setBounds(184, 86, 96, 19);
		panel_3.add(textField_31);
		textField_31.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("--------------------------");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 32));
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setBounds(20, 113, 325, 19);
		panel_3.add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("--------------------------");
		lblNewLabel_4_1.setForeground(Color.WHITE);
		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.PLAIN, 32));
		lblNewLabel_4_1.setBounds(20, 152, 325, 19);
		panel_3.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_5 = new JLabel("PAY :-");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setBounds(40, 128, 97, 27);
		panel_3.add(lblNewLabel_5);
		
		textField_32 = new JTextField();
		textField_32.setFont(new Font("Tahoma", Font.BOLD, 19));
		textField_32.setEnabled(false);
		textField_32.setBounds(184, 136, 96, 19);
		panel_3.add(textField_32);
		textField_32.setColumns(10);
		
		JButton btnNewButton_3 = new JButton("ORDER");
		btnNewButton_3.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e)
			{
				
						int a=JOptionPane.showConfirmDialog(frame,"CONFIRM YOUR ORDER?");
						if(a==JOptionPane.YES_OPTION)
						{	
							dispose();
			                feedback ef = new feedback();
			                ef.setVisible(true);
						}		
					
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_3.setBounds(22, 181, 115, 43);
		panel_3.add(btnNewButton_3);
		
		JComboBox hey = new JComboBox();
		hey.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(hey.getSelectedItem().toString().equals("COD"))
				{
					JOptionPane.showMessageDialog(null,hey.getSelectedItem().toString()+"is selected");
					
				}
				else if (hey.getSelectedItem().toString().equals("OTHER"))
				{
					
					dispose();
	                pymt ef = new pymt();
	                ef.setVisible(true);
				}

								
			}
		});
		hey.setFont(new Font("Tahoma", Font.BOLD, 20));
		hey.setModel(new DefaultComboBoxModel(new String[] {"MODE", "COD", "OTHER"}));
		hey.setBounds(199, 181, 98, 43);
		panel_3.add(hey);
		
		JButton btnNewButton = new JButton("TOTAL");
		btnNewButton.setBounds(785, 513, 103, 52);
		contentPane.add(btnNewButton);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				isum [0]= Integer.parseInt(textField.getText());
				isum [1]= Integer.parseInt(textField_1.getText());
				isum [2]= Integer.parseInt(textField_2.getText());
				isum [3]= Integer.parseInt(textField_3.getText());
				isum [4]= Integer.parseInt(textField_4.getText());
				isum [5]= Integer.parseInt(textField_5.getText());
				isum [6]= Integer.parseInt(textField_6.getText());
				isum [7]= Integer.parseInt(textField_7.getText());
				isum [8]= Integer.parseInt(textField_8.getText());
				isum [9]= Integer.parseInt(textField_9.getText());
				isum [10]= Integer.parseInt(textField_10.getText());
				isum [11]= Integer.parseInt(textField_11.getText());
				isum [12]= Integer.parseInt(textField_12.getText());
				isum [13]= Integer.parseInt(textField_13.getText());
				isum [14]= Integer.parseInt(textField_14.getText());
				isum [15]= Integer.parseInt(textField_15.getText());
				isum [16]= Integer.parseInt(textField_16.getText());
				isum [17]= Integer.parseInt(textField_17.getText());
				isum [18]= Integer.parseInt(textField_18.getText());
				isum [19]= Integer.parseInt(textField_19.getText());
				isum [20]= Integer.parseInt(textField_20.getText());
				isum [21]= Integer.parseInt(textField_21.getText());
				isum [22]= Integer.parseInt(textField_22.getText());
				isum [23]= Integer.parseInt(textField_23.getText());
				isum [24]= Integer.parseInt(textField_24.getText());
				isum [25]= Integer.parseInt(textField_25.getText());
				isum [26]= Integer.parseInt(textField_26.getText());
				isum [27]= Integer.parseInt(textField_27.getText());
				isum [28]= Integer.parseInt(textField_28.getText());
				iamt= isum[0] * 100 +isum[1]*120+isum[2]*250+isum[3]*120+isum[4]*300+isum[5]*280+isum[6]*80+isum[7]*100+isum[8]*150+isum[9]*110+isum[10]*100+isum[11]*90+isum[12]*80+isum[13]*90+isum[14]*70+isum[15]*80+isum[16]*85+isum[17]*90+isum[18]*70+isum[19]*80+isum[20]*70+isum[21]*80+isum[22]*90+isum[23]*100+isum[24]*50+isum[25]*50+isum[26]*50+isum[27]*70+isum[28]*60;
			itax=(iamt*tax)/100 ;
			ipay=iamt+itax+div;
			String iav=String.format("Rs.%d",div);
			textField_31.setText(iav);
			String iafv=String.format("Rs.%d",itax);
			textField_30.setText(iafv);
				String isub =String.format("Rs.%d",iamt);
			textField_29.setText(isub);
			String isb =String.format("%d",ipay);
			textField_32.setText(isb);
			           String  total_amt,taxes,delivery,rced_pymt;
			
			total_amt=textField_29.getText();
			taxes=textField_30.getText();
			delivery=textField_31.getText();
			rced_pymt=textField_32.getText();
			
			try
			{
			//registring the driver
				
		   Class.forName("com.ibm.db2.jcc.DB2Driver");
			Connection con = DriverManager.getConnection("jdbc:db2://localhost:50000/db1","db2admin", "123456789");
			PreparedStatement ps =con.prepareStatement("insert into tab7 values(?,?,?,?)");
			ps.setString(1,total_amt);
			ps.setString(4,rced_pymt);
			ps.setString(3, delivery);
			ps.setString(2, taxes);
			
			
			
			ps.executeUpdate();
			
			}
			catch(Exception e1)
			{
				e1.getStackTrace();
			}
			}
		});
		
	}
}
