import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class user extends JFrame {

	private JPanel contentPane;
	static user frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new user();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public user() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 791, 427);
		contentPane = new JPanel();
		contentPane.setBackground(Color.PINK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Let's get it  :-D");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 35));
		lblNewLabel.setBounds(23, 33, 525, 61);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel(".........Hurry up your food is waitig......");
		lblNewLabel_1.setFont(new Font("Dialog", Font.PLAIN, 28));
		lblNewLabel_1.setBounds(177, 183, 569, 61);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Log in");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Welcome to the login page");
				dispose();
				user_login obj = new user_login();
				obj.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 45));
		btnNewButton.setBounds(100, 302, 229, 69);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Register");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				user_regis obj = new user_regis ();
				obj.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 45));
		btnNewButton_1.setBounds(517, 305, 229, 63);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("If you are a new user register first.......");
		lblNewLabel_2.setFont(new Font("Dialog", Font.PLAIN, 33));
		lblNewLabel_2.setBounds(46, 116, 656, 41);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("");
		//Image img18 = new ImageIcon(this.getClass().getResource("/WhatsApp Image 2021-07-21 at 13.10.47.jpeg")).getImage();
		lblNewLabel_3 .setIcon(new ImageIcon(this.getClass().getResource("/image/WhatsApp Image 2021-07-21 at 13.10.47.jpeg")));
		//lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\Vanshita\\eclipse-workspace\\food\\image\\WhatsApp Image 2021-07-21 at 13.10.47.jpeg"));
		lblNewLabel_3.setBounds(23, 167, 122, 125);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("New label");
		lblNewLabel_4 .setIcon(new ImageIcon(this.getClass().getResource("/image/WhatsApp Image 2021-07-21 at 13.10.46.jpeg")));
		//lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\Vanshita\\eclipse-workspace\\food\\image\\WhatsApp Image 2021-07-21 at 13.10.46.jpeg"));
		lblNewLabel_4.setBounds(610, 10, 157, 196);
		contentPane.add(lblNewLabel_4);
	}
}
