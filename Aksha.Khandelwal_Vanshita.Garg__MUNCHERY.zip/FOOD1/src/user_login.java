import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.jar.Attributes.Name;
import java.awt.event.ActionEvent;

public class user_login extends JFrame {

	private JPanel contentPane;
	private JPasswordField pass;
	private JTextField id;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					user_login frame = new user_login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public user_login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 807, 478);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setFont(new Font("Algerian", Font.BOLD | Font.ITALIC, 40));
		lblNewLabel.setBounds(21, 77, 335, 100);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setFont(new Font("Algerian", Font.BOLD | Font.ITALIC, 40));
		lblNewLabel_1.setBounds(21, 227, 305, 80);
		contentPane.add(lblNewLabel_1);
		
		pass = new JPasswordField();
		pass.setFont(new Font("Tahoma", Font.PLAIN, 30));
		pass.setBounds(382, 243, 373, 56);
		contentPane.add(pass);
		
		id = new JTextField();
		id.setFont(new Font("Tahoma", Font.PLAIN, 30));
		id.setBounds(382, 103, 373, 56);
		contentPane.add(id);
		id.setColumns(10);
		
		
	        
		
		JButton log = new JButton("Log In");
		log.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name= id.getText();
				String password =pass.getText();
				
				try
				{
					
				
				 Class.forName("com.ibm.db2.jcc.DB2Driver");
					Connection con = DriverManager.getConnection("jdbc:db2://localhost:50000/db1","db2admin", "123456789");
					Statement st =con.createStatement();
					PreparedStatement ps =con.prepareStatement("select name,password from tab4 where name=? and password=?");
					ps.setString(1, name);
					ps.setString(2, password);
					ResultSet rs=ps.executeQuery();
					if(rs.next())
					{
						JOptionPane.showMessageDialog(null, "You have successfully logged in.......");
						dispose();
						menu1 obj = new menu1();
						obj.setVisible(true);
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Wrong username or password...");
					}
					
					
					
				}
				catch(Exception e1)
				{
					e1.printStackTrace();
				}
				
			
				
			}
		});
		log.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 40));
		log.setBounds(260, 357, 315, 73);
		contentPane.add(log);
	}
}