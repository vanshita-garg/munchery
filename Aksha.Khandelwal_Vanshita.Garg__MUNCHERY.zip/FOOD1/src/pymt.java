import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class pymt extends JFrame {

	private JPanel contentPane;
	private JTextField ccn;
	private JTextField date;
	private JTextField cv;
	private JTextField amount;
static pymt frame ;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new pymt();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public pymt() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 894, 667);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Credit Card Number");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel_1.setBounds(5, 244, 320, 80);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Expiration date");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel_2.setBounds(10, 318, 339, 80);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("CVS");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel_3.setBounds(10, 409, 281, 67);
		contentPane.add(lblNewLabel_3);
		
		ccn = new JTextField();
		ccn.setFont(new Font("Tahoma", Font.PLAIN, 29));
		ccn.setBounds(454, 257, 380, 50);
		contentPane.add(ccn);
		ccn.setColumns(10);
		
		date = new JTextField();
		date.setFont(new Font("Tahoma", Font.PLAIN, 29));
		date.setBounds(454, 318, 380, 63);
		contentPane.add(date);
		date.setColumns(10);
		
		cv = new JTextField();
		cv.setFont(new Font("Tahoma", Font.PLAIN, 29));
		cv.setBounds(454, 398, 380, 67);
		contentPane.add(cv);
		cv.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4 .setIcon(new ImageIcon(pymt.class.getResource("/image/WhatsApp Image 2021-07-22 at 13.02.52.jpeg")));
		//lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\db2admin\\Downloads\\WhatsApp Image 2021-07-18 at 21.21.27.jpeg"));
		lblNewLabel_4.setBounds(223, 0, 400, 252);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel = new JLabel("Amount");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel.setBounds(10, 487, 271, 57);
		contentPane.add(lblNewLabel);
		
		amount = new JTextField();
		amount.setFont(new Font("Tahoma", Font.PLAIN, 29));
		amount.setBounds(454, 476, 380, 68);
		contentPane.add(amount);
		amount.setColumns(10);
		
		JButton btnNewButton = new JButton("Pay");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				String card=ccn.getText();
				String ed=date.getText();
                String cvs=cv.getText();
                String a=amount.getText();
                JOptionPane.showMessageDialog(null, "Payment confirmed and food is on the way.......");
                dispose();
                thanks ef = new thanks();
                ef.setVisible(true);
				}
		});
		btnNewButton.setFont(new Font("Bell MT", Font.BOLD | Font.ITALIC, 45));
		btnNewButton.setBounds(230, 567, 271, 63);
		contentPane.add(btnNewButton);
	}
}