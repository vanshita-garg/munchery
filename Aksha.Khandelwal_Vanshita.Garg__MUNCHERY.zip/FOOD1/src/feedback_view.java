import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.JScrollPane;

public class feedback_view extends JFrame 
{

	protected static final String s = null;
	private JPanel contentPane;
	private JTable table;
	private JButton btnNewButton_1;
static feedback_view frame;
private JSeparator separator;
private JScrollPane scrollPane;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try 
				{
					 frame = new feedback_view();
					frame.setVisible(true);
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public feedback_view()
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 579, 349);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(245, 245, 245));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("show");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					Class.forName("com.ibm.db2.jcc.DB2Driver");
					Connection con=DriverManager.getConnection("jdbc:db2://localhost:50000/db1","db2admin","123456789");
				    Statement st = con.createStatement();
				    String v = "select * from tab2";
				    ResultSet rs = st.executeQuery(v);
				    while(rs.next())
				    {
				    	String name = rs.getString("name");
				    	String tab = rs.getString("feedback");
				    	String tbData[]= {name,tab};
				    	DefaultTableModel tblModel=(DefaultTableModel)table.getModel();
				    	tblModel.addRow(tbData);
				    }
				  }
				    catch(Exception e2)
					{
						e2.printStackTrace();
					}
				}
			
		});
		btnNewButton.setBounds(39, 17, 125, 30);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("<<back");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
		     	admin_view dv = new admin_view();
				dv.setVisible(true);
				
			}
		});
		btnNewButton_1.setBounds(386, 21, 125, 30);
		contentPane.add(btnNewButton_1);
		
		separator = new JSeparator();
		separator.setBounds(20, 77, 535, 2);
		contentPane.add(separator);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 89, 545, 213);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setBorder(new LineBorder(new Color(0, 0, 0), 0, true));
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"NAME", "FEEDBACK"
			}
		));
	}

}
